/** @file The actions the Cluster sidebar starts, built from the command dependencies. */
import {
	promptAndCreate,
	promptAndDelete,
	promptAndEdit
} from './clusterManagement';
import {
	promptAndPair,
	promptAndUnlink
} from './clusterPairing';
import type { CommandDependencies } from '../types';

/** What the sidebar can start. Each takes a Cluster id, except creation. */
export interface SidebarHandlers {
	/** Starts unlinking a Cluster, after a confirmation. */
	onConfirmUnlink: (id: string) => void;
	/** Starts creating an empty Cluster. */
	onCreateCluster: () => void;
	/** Starts deleting a Cluster, after a confirmation. */
	onDeleteCluster: (id: string) => void;
	/** Starts editing a Cluster. */
	onEditCluster: (id: string) => void;
	/** Starts pairing a Cluster. */
	onPair: (id: string) => void;
}

/**
 * Builds the sidebar's actions over the plugin's prompts.
 *
 * @param dependencies - What the actions need from the plugin.
 * @returns The actions.
 */
export function buildSidebarHandlers(dependencies: CommandDependencies): SidebarHandlers {
	const {
		settingsStore,
		promptForCluster,
		promptForClusterChoice,
		promptForConfirmation
	} = dependencies;

	return {
		onConfirmUnlink: (id) => {
			const cluster = settingsStore.get().clusters[id];
			if (cluster !== undefined) {
				promptAndUnlink(
					settingsStore,
					promptForClusterChoice,
					promptForConfirmation,
					[cluster]
				);
			}
		},
		onCreateCluster: () => {
			promptAndCreate(
				settingsStore,
				promptForCluster,
				[]
			);
		},
		onDeleteCluster: (id) => {
			promptAndDelete(
				settingsStore,
				promptForConfirmation,
				id
			);
		},
		onEditCluster: (id) => {
			promptAndEdit(
				settingsStore,
				promptForCluster,
				id
			);
		},
		onPair: (id) => {
			promptAndPair(
				settingsStore,
				promptForClusterChoice,
				promptForConfirmation,
				id
			);
		},
	};
}
