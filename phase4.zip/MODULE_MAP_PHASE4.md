# Phase 4 module map

Verified: typecheck clean, lint clean, build OK, 60 files / 935 tests passing. Apply on top of Phases 1–3. Nothing is removed in this phase.

## New
- src/obsidian/ReactItemView.ts        abstract base: root lifecycle (open/close), `hostClass`, `renderApp()`
- src/obsidian/vaultWatch.ts + test    watchVault(app, registerEvent, { onChange, onDelete, onRename }); onChange = create + modify
- src/obsidian/prompts.ts              buildPrompts(app) -> the five prompts (moved out of runtime.ts)
- src/clusters/sidebarHandlers.ts + test   buildSidebarHandlers(dependencies) -> the five sidebar actions (moved out of runtime.ts)

## Revised
- src/obsidian/TabCandyView.tsx        extends ReactItemView; constructor unchanged
- src/obsidian/ClusterSidebarView.tsx  extends ReactItemView; constructor is now (dependencies, leaf) instead of seven arguments
- src/obsidian/vaultWatchers.ts        three watchers rebuilt on watchVault; behavior unchanged
- src/settings/normalizeSettings.ts    booleans, strings and enums driven by typed tables (see below)
- src/runtime.ts                       307 -> 158 lines: one CommandDependencies object feeds the sidebar, commands and menu
- src/obsidian/clusterSidebarView.test.tsx   new constructor

## Enum type-checking (your question E)
Same issue, solved at compile time. `BOOLEAN_FIELDS`, `STRING_FIELDS` and `ENUM_FIELDS` are typed against `TabCandySettings`:
- a new boolean/string/enum setting not listed in its table fails to compile
- an enum setting paired with the wrong enum fails to compile (verified by temporarily breaking both)
Runtime validation still runs on every field, since the saved data is untrusted. Arrays, search providers, the contrast cache and Clusters stay explicit.
